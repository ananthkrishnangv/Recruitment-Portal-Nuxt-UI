"use client";
import { Button as HeroButton } from "@heroui/react";
import Link from "next/link";
import { cn } from "@/lib/utils";
import type { ButtonHTMLAttributes, ReactNode } from "react";

type ButtonVariant = "primary" | "outline" | "ghost" | "danger" | "success" | "secondary";
type ButtonSize = "sm" | "md" | "lg";

type Props = Omit<ButtonHTMLAttributes<HTMLButtonElement>, "value"> & {
  href?: string;
  variant?: ButtonVariant;
  size?: ButtonSize;
  loading?: boolean;
  icon?: ReactNode;
  children?: ReactNode;
  className?: string;
  value?: string;
};

export function Button({
  className,
  variant = "primary",
  size = "md",
  loading = false,
  icon,
  href,
  children,
  disabled,
  value,
  ...props
}: Props) {
  let uiVariant: any = "primary";

  switch (variant) {
    case "primary": uiVariant = "primary"; break;
    case "outline": uiVariant = "outline"; break;
    case "ghost": uiVariant = "ghost"; break;
    case "danger": uiVariant = "danger"; break;
    case "success": uiVariant = "primary"; break;
    case "secondary": uiVariant = "secondary"; break;
  }

  const content = (
    <>
      {loading && <span className="mr-2 animate-spin w-4 h-4 border-2 border-current border-t-transparent rounded-full" />}
      {!loading && icon && <span className="mr-2">{icon}</span>}
      {children}
    </>
  );

  const commonProps = {
    variant: uiVariant,
    size,
    isDisabled: disabled || loading,
    className: cn("font-medium", className),
    value: typeof value === 'string' ? value : undefined,
    ...props
  };

  if (href) {
    return (
      <Link href={href} className={commonProps.className} style={{ display: 'inline-flex' }}>
        <HeroButton {...(commonProps as any)} className="w-full h-full">
          {content}
        </HeroButton>
      </Link>
    );
  }

  return (
    <HeroButton {...(commonProps as any)}>
      {content}
    </HeroButton>
  );
}
