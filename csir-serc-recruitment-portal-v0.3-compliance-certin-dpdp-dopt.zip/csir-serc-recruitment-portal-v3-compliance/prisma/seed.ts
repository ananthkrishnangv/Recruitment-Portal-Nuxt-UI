import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();

async function main() {
  const post = await prisma.recruitmentPost.upsert({
    where: { postCode: "TO-2026" },
    update: {
      categoryMatrix: { UR: 2, OBC: 2, SC: 1, ST: 1, EWS: 1, PwBD: 1 },
      eligibilityRule: { maxAge: 35, essentialQualification: "BE/BTech or equivalent", minimumExperienceYears: 3 }
    },
    create: {
      postCode: "TO-2026",
      title: "Technical Officer",
      advertisementNo: "CSIR-SERC/RECT/2026/01",
      crucialDate: new Date("2026-06-30"),
      openingDate: new Date("2026-06-01"),
      closingDate: new Date("2026-07-15"),
      categoryMatrix: { UR: 2, OBC: 2, SC: 1, ST: 1, EWS: 1, PwBD: 1 },
      eligibilityRule: { maxAge: 35, essentialQualification: "BE/BTech or equivalent", minimumExperienceYears: 3 },
      feeRule: { UR: 500, OBC: 500, EWS: 500, SC: 0, ST: 0, PwBD: 0 }
    }
  });

  const vacancyRows = [
    ["UR", 2, 0, 0], ["OBC", 2, 0, 0], ["SC", 1, 0, 0], ["ST", 1, 0, 0], ["EWS", 1, 0, 0], ["PwBD", 1, 0, 1]
  ] as const;
  for (const [category, vacancyCount, backlogCount, horizontalPwbdCount] of vacancyRows) {
    await prisma.postCategoryVacancy.upsert({
      where: { postId_category: { postId: post.id, category } },
      update: { vacancyCount, backlogCount, horizontalPwbdCount },
      create: { postId: post.id, category, vacancyCount, backlogCount, horizontalPwbdCount, remarks: `${category} vacancy allocation` }
    });
  }

  const admin = await prisma.user.upsert({
    where: { mobile: "9000000000" },
    update: {},
    create: { mobile: "9000000000", name: "Demo Admin", role: "ADMIN" }
  });

  const applicants = [
    ["9876543210", "Anita Raman", "UR", "1993-05-10", "UNDER_SCRUTINY"],
    ["9876543211", "Rahul Menon", "OBC", "1991-02-12", "DEFICIENCY_RAISED"],
    ["9876543212", "Farida Khan", "EWS", "1995-09-20", "RECOMMENDED"],
    ["9876543213", "S. Karthik", "SC", "1990-11-05", "PAYMENT_SUCCESS"]
  ] as const;

  for (let i = 0; i < applicants.length; i++) {
    const [mobile, name, category, dob, status] = applicants[i];
    const user = await prisma.user.upsert({
      where: { mobile },
      update: {},
      create: { mobile, name, role: "APPLICANT", aadhaarLast4: String(1234 + i), consentVersion: "DPDP-v1", consentAt: new Date() }
    });
    await prisma.application.upsert({
      where: { applicationNo: `APP-20260602-${String(i + 1).padStart(4, "0")}` },
      update: {},
      create: {
        applicationNo: `APP-20260602-${String(i + 1).padStart(4, "0")}`,
        applicantId: user.id,
        postId: post.id,
        status: status as any,
        category,
        dob: new Date(dob),
        formData: { qualification: "BE Civil", experienceYears: 5 + i, fatherName: "Demo Parent" },
        eligibilityResult: { eligible: true, ruleVersion: "DEMO-DOPT-CSIR-v1" },
        validationResult: { valid: true, vacancyCategoryAvailable: true, requiredDocuments: ["Photo", "Signature", "DOB Proof"] },
        paymentStatus: "Success",
        submittedAt: new Date()
      }
    });
  }

  await prisma.consentNotice.upsert({
    where: { version: "DPDP-v1" },
    update: { active: true },
    create: {
      version: "DPDP-v1",
      title: "Consent Notice for CSIR-SERC Recruitment Portal",
      language: "en",
      active: true,
      body: "Your personal data will be processed only for recruitment application processing, eligibility validation, payment reconciliation, scrutiny, audit, grievance handling, and legal/records compliance. Aadhaar, if provided, is used only as a local identifier and is not authenticated with UIDAI."
    }
  });

  const settings: [string, any, boolean][] = [
    ["portal.title", "CSIR-SERC Recruitment Portal", false],
    ["portal.helpdeskEmail", "recruitment-helpdesk@example.gov.in", false],
    ["notification.smtp.host", "", true],
    ["notification.smtp.port", "587", false],
    ["notification.smtp.fromEmail", "noreply@example.gov.in", false],
    ["notification.smtp.tls", true, false],
    ["notification.whatsapp.enabled", false, false],
    ["notification.whatsapp.provider", "", false],
    ["notification.whatsapp.apiEndpoint", "", true],
    ["notification.whatsapp.templateApplicationSubmitted", "", false],
    ["notification.telegram.enabled", false, false],
    ["security.certin.incidentReportingHours", 6, false],
    ["security.certin.logRetentionDays", 180, false],
    ["security.otpExpiryMinutes", 10, false]
  ];
  for (const [key, value, isSecret] of settings) {
    await prisma.siteSetting.upsert({ where: { key }, update: { value, isSecret }, create: { key, value, isSecret, updatedBy: admin.id } });
  }

  const controls = [
    ["CERTIN-LOG-180", "Security log retention configured", "CERT-In"],
    ["CERTIN-INC-6H", "Cyber incident reporting workflow within prescribed window", "CERT-In"],
    ["CERTIN-AUDIT", "CERT-In empanelled audit evidence tracker", "CERT-In"],
    ["DPDP-NOTICE", "Consent notice before data processing", "DPDP Act 2023"],
    ["DPDP-ERASURE", "Correction and erasure request workflow", "DPDP Act 2023"],
    ["DOPT-RES", "SC/ST/OBC/EWS/PwBD vacancy category validation", "DoPT/CSIR"],
    ["DOPT-AGE", "Age relaxation and crucial date validation", "DoPT/CSIR"]
  ] as const;
  for (const [controlCode, controlName, framework] of controls) {
    await prisma.securityControlCheck.upsert({ where: { controlCode }, update: {}, create: { controlCode, controlName, framework, status: "IMPLEMENTED_DEMO" } });
  }
}
main().finally(() => prisma.$disconnect());
