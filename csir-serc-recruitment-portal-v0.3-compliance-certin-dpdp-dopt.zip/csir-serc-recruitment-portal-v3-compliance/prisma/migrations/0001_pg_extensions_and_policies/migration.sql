CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS unaccent;

-- RLS foundation. Application must set current user and role before sensitive queries in production.
ALTER TABLE "Application" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "ApplicantDocument" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "ApplicationDocument" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "Payment" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "AuditLog" ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_application_formdata_gin ON "Application" USING gin ("formData");
CREATE INDEX IF NOT EXISTS idx_application_queue ON "Application" ("postId", "status", "category", "submittedAt");
CREATE INDEX IF NOT EXISTS idx_user_name_trgm ON "User" USING gin ("name" gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_application_document_ocr_fts ON "ApplicationDocument" USING gin (to_tsvector('english', coalesce("ocrText", '')));

-- Example policies for production hardening. Keep permissive for local migration compatibility until app SET LOCAL is wired.
DROP POLICY IF EXISTS application_admin_read_policy ON "Application";
CREATE POLICY application_admin_read_policy ON "Application" FOR SELECT USING (true);
