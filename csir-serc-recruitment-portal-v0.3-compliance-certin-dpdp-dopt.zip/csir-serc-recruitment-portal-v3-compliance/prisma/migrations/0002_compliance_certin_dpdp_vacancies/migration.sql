-- Compliance integration migration notes:
-- Run `prisma migrate dev` after updating schema. Prisma will create tables from schema.
-- Additional PostgreSQL indexes/checks for compliance-heavy queries.

CREATE INDEX IF NOT EXISTS idx_auditlog_certin_retention ON "AuditLog" ("createdAt", "action");
CREATE INDEX IF NOT EXISTS idx_certin_incident_status ON "CertInIncident" ("status", "severity", "detectedAt");
CREATE INDEX IF NOT EXISTS idx_post_category_vacancy ON "PostCategoryVacancy" ("postId", "category");

-- Suggested production retention control: retain application/security logs for CERT-In-aligned period as per policy.
-- Do not auto-delete audit logs without approved records retention SOP.
