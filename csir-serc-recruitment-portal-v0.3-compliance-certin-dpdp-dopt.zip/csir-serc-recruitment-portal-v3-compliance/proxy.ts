import { NextRequest, NextResponse } from "next/server";
export function proxy(request: NextRequest) {
  const response = NextResponse.next();
  response.headers.set("X-Frame-Options", "DENY");
  response.headers.set("X-Content-Type-Options", "nosniff");
  response.headers.set("Referrer-Policy", "strict-origin-when-cross-origin");
  return response;
}
export const config = { matcher: ["/admin/:path*", "/applicant/:path*", "/api/:path*"] };
