import type { Metadata } from "next";
import { Noto_Sans, Montserrat } from "next/font/google";
import "./globals.css";

const notoSans = Noto_Sans({ subsets: ["latin", "devanagari"], variable: "--font-noto-sans", display: "swap" });
const montserrat = Montserrat({ subsets: ["latin"], variable: "--font-montserrat", display: "swap" });

export const metadata: Metadata = {
  title: "CSIR-SERC Recruitment Portal",
  description: "Advanced Recruitment Portal for CSIR-SERC"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body className={`${notoSans.variable} ${montserrat.variable}`}>{children}</body></html>;
}
