import { NextResponse } from "next/server";
import { prisma } from "@/lib/db/prisma";
import { writeAuditLog } from "@/lib/audit/hash-chain";
export async function GET() {
  const rows = await prisma.application.findMany({ include:{ applicant:true, post:true }, orderBy:{ updatedAt:'desc' } });
  const csv = ["Application No,Name,Post,Category,Status,Payment,Submitted", ...rows.map(r => `${r.applicationNo},${r.applicant.name},${r.post.title},${r.category},${r.status},${r.paymentStatus ?? ""},${r.submittedAt?.toISOString() ?? ""}`)].join("\n");
  await writeAuditLog({ action:"APPLICATION_EXPORT_CSV", entityType:"Application", entityId:"bulk", afterJson:{ count: rows.length } });
  return new NextResponse(csv, { headers: { "Content-Type": "text/csv", "Content-Disposition": "attachment; filename=applications.csv" } });
}
