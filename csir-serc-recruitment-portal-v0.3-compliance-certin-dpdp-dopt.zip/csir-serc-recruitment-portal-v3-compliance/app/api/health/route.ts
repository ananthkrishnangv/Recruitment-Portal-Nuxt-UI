import { NextResponse } from "next/server";
import { prisma } from "@/lib/db/prisma";
export async function GET() {
  try { await prisma.$queryRaw`SELECT 1`; return NextResponse.json({ ok:true, db:true, at:new Date().toISOString() }); }
  catch { return NextResponse.json({ ok:false, db:false }, { status: 503 }); }
}
