import { prisma } from "@/lib/db/prisma";
import { ApplicationGrid } from "@/components/admin/ApplicationGrid";
export default async function ApplicationsPage(){
 const applications = await prisma.application.findMany({ include:{ applicant:{ select:{ name:true } }, post:{ select:{ title:true } } }, orderBy:{ updatedAt:'desc' } });
 const rows = applications.map(a => ({ applicationNo:a.applicationNo, applicant:a.applicant, post:a.post, category:a.category, status:a.status, paymentStatus:a.paymentStatus, submittedAt:a.submittedAt?.toISOString() ?? null }));
 return <div><div className="mb-5 glass-card p-5"><h1 className="heading-font text-3xl font-bold text-blue-950">Applications — Airtable Style View</h1><p className="mt-2 text-sm text-slate-600">Prisma-backed saved views, colour tags, post-wise export and scrutiny-ready data grid.</p></div><ApplicationGrid applications={rows}/></div>
}
