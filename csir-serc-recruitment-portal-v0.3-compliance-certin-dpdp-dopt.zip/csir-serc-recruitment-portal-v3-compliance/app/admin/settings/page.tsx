import { prisma } from "@/lib/db/prisma";
import { saveSetting } from "@/app/actions/settings";
const defaults = ["portal.title","portal.helpdeskEmail","notification.smtp.host","notification.smtp.port","notification.telegram.enabled","notification.telegram.chatId","notification.whatsapp.enabled","security.otpExpiryMinutes","security.maxUploadMb"];
export default async function SettingsPage(){
 const rows = await prisma.siteSetting.findMany({ orderBy:{ key:'asc' } });
 const existing = new Set(rows.map(r=>r.key));
 const allRows = [...rows, ...defaults.filter(k=>!existing.has(k)).map(k=>({ id:k, key:k, value:"", isSecret:false, updatedAt:new Date(), updatedBy:null }))];
 return <div><div className="mb-5 glass-card p-5"><h1 className="heading-font text-3xl font-bold text-blue-950">Advanced Settings</h1><p className="mt-2 text-sm text-slate-600">Manage site, SMTP, Telegram, optional WhatsApp, security and accessibility settings. All changes are audit logged.</p></div><div className="grid gap-4 md:grid-cols-2">{allRows.map(s=><form key={s.key} action={saveSetting} className="glass-card p-5"><h2 className="heading-font text-lg font-bold text-blue-950">{s.key}</h2><input type="hidden" name="key" value={s.key}/><label className="mt-3 block text-sm font-semibold">Value<input name="value" className="input mt-1" defaultValue={typeof s.value === 'string' ? s.value : JSON.stringify(s.value)}/></label><label className="mt-3 flex items-center gap-2 text-sm"><input type="checkbox" name="isSecret" defaultChecked={s.isSecret}/> Secret / masked setting</label><button className="mt-4 rounded-xl bg-blue-700 px-4 py-2 text-sm font-bold text-white">Save</button></form>)}</div></div>
}
