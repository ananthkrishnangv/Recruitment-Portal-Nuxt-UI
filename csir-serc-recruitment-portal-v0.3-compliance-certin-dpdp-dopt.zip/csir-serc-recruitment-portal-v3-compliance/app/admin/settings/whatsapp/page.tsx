import { prisma } from "@/lib/db/prisma";
import { saveSetting } from "@/app/actions/settings";

const keys = ["notification.whatsapp.enabled", "notification.whatsapp.provider", "notification.whatsapp.apiEndpoint", "notification.whatsapp.apiToken", "notification.whatsapp.templateApplicationSubmitted", "notification.whatsapp.templateDeficiency", "notification.whatsapp.consentRequired"];
export default async function WhatsAppSettingsPage() {
  const rows = await prisma.siteSetting.findMany({ where: { key: { in: keys } }, orderBy: { key: "asc" } });
  const map = new Map(rows.map(r => [r.key, r]));
  return <div><section className="glass-card p-5"><h1 className="heading-font text-3xl font-bold text-blue-950">Optional WhatsApp Notification Settings</h1><p className="mt-2 text-sm text-slate-600">Configure optional WhatsApp notification provider only after applicant consent and approved provider onboarding. Email/SMS fallback should remain available.</p></section><div className="mt-5 grid gap-4 md:grid-cols-2">{keys.map(k => { const s = map.get(k); return <form key={k} action={saveSetting} className="glass-card p-5"><input type="hidden" name="key" value={k}/><h2 className="heading-font text-lg font-bold text-blue-950">{k}</h2><input name="value" className="input mt-3" defaultValue={s ? String(s.value).replace(/^"|"$/g,'') : ""}/><label className="mt-3 flex items-center gap-2 text-sm"><input type="checkbox" name="isSecret" defaultChecked={k.includes('Token') || k.includes('Endpoint')}/> Secret</label><button className="mt-4 rounded-xl bg-emerald-600 px-4 py-2 text-sm font-bold text-white">Save</button></form>})}</div></div>;
}
