import { redirect } from "next/navigation";
import { prisma } from "@/lib/db/prisma";
import { getApplicantUser } from "@/lib/auth/session";
import { acceptDpdpConsent } from "@/app/actions/consent";
import { Button } from "@/components/ui/button";

export default async function ConsentPage() {
  const user = await getApplicantUser();
  if (!user) redirect("/auth/login");
  const notice = await prisma.consentNotice.findFirst({ where: { active: true }, orderBy: { createdAt: "desc" } });
  const records = await prisma.consentRecord.findMany({ where: { userId: user.id }, include: { notice: true }, orderBy: { createdAt: "desc" } });
  return <main className="min-h-screen gradient-shell p-4 md:p-8"><div className="mx-auto max-w-5xl"><section className="glass-card p-6"><h1 className="heading-font text-3xl font-bold text-blue-950">DPDP Consent Notice</h1><p className="mt-2 text-sm text-slate-600">Consent is captured before processing personal data for recruitment purposes. Aadhaar, if provided, remains local-only and is not authenticated with UIDAI.</p><div className="mt-5 rounded-2xl bg-white/75 p-5"><h2 className="font-bold text-blue-950">{notice?.title ?? 'Consent notice not configured'}</h2><p className="mt-3 whitespace-pre-wrap text-sm leading-6 text-slate-700">{notice?.body}</p></div><form action={acceptDpdpConsent} className="mt-5"><input type="hidden" name="purpose" value="Recruitment application processing, eligibility validation, scrutiny, audit and communication"/><label className="flex items-start gap-3 text-sm"><input type="checkbox" name="accepted" required className="mt-1"/> I have read and consent to the processing of my personal data for the stated recruitment purposes.</label><Button className="mt-4">Record Consent</Button></form></section><section className="mt-6 glass-card p-6"><h2 className="heading-font text-xl font-bold text-blue-950">Consent History</h2><div className="mt-3 space-y-2">{records.map(r=><div key={r.id} className="rounded-2xl bg-white/75 p-3 text-sm"><strong>{r.notice.version}</strong> · {r.purpose} · {r.accepted ? 'Accepted' : 'Rejected'} · {r.createdAt.toLocaleString('en-IN')}</div>)}</div></section></div></main>;
}
