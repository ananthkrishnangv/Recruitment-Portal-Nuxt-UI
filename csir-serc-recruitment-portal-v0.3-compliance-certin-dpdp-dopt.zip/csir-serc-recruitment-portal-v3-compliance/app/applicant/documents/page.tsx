import { getApplicantUser } from "@/lib/auth/session";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/db/prisma";
import { uploadVaultDocument } from "@/app/actions/documents";

export default async function DocumentsPage(){
 const user = await getApplicantUser(); if(!user) redirect('/auth/login');
 const docs = await prisma.applicantDocument.findMany({ where:{ applicantId:user.id }, orderBy:{ uploadedAt:'desc' } });
 const types = ['Photo','Signature','DOB Proof','Community Certificate','Educational Certificate','Experience Certificate'];
 return <main className="min-h-screen gradient-shell p-4 md:p-8"><div className="mx-auto max-w-6xl"><h1 className="heading-font text-3xl font-bold text-blue-950">Applicant Document Vault</h1><p className="mt-2 text-slate-600">Reusable preloaded documents linked to applicant login. Final submitted applications lock document version hashes.</p><section className="mt-6 glass-card p-5"><h2 className="heading-font text-xl font-bold text-blue-950">Upload Document</h2><form action={uploadVaultDocument} className="mt-4 grid gap-3 md:grid-cols-[220px_1fr_auto]"><select name="documentType" className="input">{types.map(t=><option key={t}>{t}</option>)}</select><input name="file" type="file" className="input" accept="application/pdf,image/png,image/jpeg,image/webp"/><button className="rounded-2xl bg-blue-700 px-5 py-3 text-sm font-bold text-white">Upload</button></form></section><div className="mt-6 grid gap-4 md:grid-cols-3">{docs.map(d=><div key={d.id} className="glass-card p-5"><h2 className="font-bold text-blue-950">{d.documentType}</h2><p className="mt-2 text-sm text-slate-600">{d.originalName}<br/>Version {d.version} · {(d.sizeBytes/1024).toFixed(1)} KB</p><p className="mt-2 break-all text-xs text-slate-500">SHA-256: {d.fileHash}</p></div>)}{!docs.length && types.map(d=><div key={d} className="glass-card p-5"><h2 className="font-bold text-blue-950">{d}</h2><p className="mt-2 text-sm text-slate-600">No file uploaded.</p></div>)}</div></div></main>
}
