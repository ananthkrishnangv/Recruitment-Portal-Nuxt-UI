import { cn } from "@/lib/utils";
const map: Record<string, string> = {
  DRAFT: "bg-slate-100 text-slate-800", SUBMITTED: "bg-blue-100 text-blue-800", PAYMENT_PENDING: "bg-orange-100 text-orange-800", PAYMENT_SUCCESS: "bg-emerald-100 text-emerald-800", UNDER_SCRUTINY: "bg-amber-100 text-amber-800", DEFICIENCY_RAISED: "bg-rose-100 text-rose-800", RECOMMENDED: "bg-green-100 text-green-800", REJECTED: "bg-red-100 text-red-800", DIRECTOR_APPROVED: "bg-teal-100 text-teal-800", LOCKED: "bg-slate-200 text-slate-900",
  UR: "bg-slate-100 text-slate-800", OBC: "bg-indigo-100 text-indigo-800", SC: "bg-purple-100 text-purple-800", ST: "bg-fuchsia-100 text-fuchsia-800", EWS: "bg-cyan-100 text-cyan-800", PwBD: "bg-teal-100 text-teal-800", Success: "bg-green-100 text-green-800"
};
export function ColourTag({ value }: { value: string }) { return <span className={cn("rounded-full px-3 py-1 text-xs font-bold", map[value] ?? "bg-slate-100 text-slate-700")}>{String(value).replaceAll("_", " ")}</span>; }
