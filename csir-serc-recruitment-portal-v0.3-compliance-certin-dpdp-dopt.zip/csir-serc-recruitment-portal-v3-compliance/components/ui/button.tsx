import Link from "next/link";
import { cn } from "@/lib/utils";
import type { ButtonHTMLAttributes, ReactNode } from "react";
type Props = ButtonHTMLAttributes<HTMLButtonElement> & { href?: string; variant?: "primary" | "outline" | "ghost"; children: ReactNode };
export function Button({ className, variant = "primary", href, children, ...props }: Props) {
  const classes = cn("focus-ring inline-flex items-center justify-center rounded-2xl px-5 py-3 text-sm font-semibold transition", variant === "primary" && "bg-blue-700 text-white shadow-lg shadow-blue-900/15 hover:bg-blue-800", variant === "outline" && "border border-emerald-600 bg-white/60 text-emerald-800 hover:bg-emerald-50", variant === "ghost" && "text-blue-800 hover:bg-blue-50", className);
  if (href) return <Link href={href} className={classes}>{children}</Link>;
  return <button className={classes} {...props}>{children}</button>;
}
