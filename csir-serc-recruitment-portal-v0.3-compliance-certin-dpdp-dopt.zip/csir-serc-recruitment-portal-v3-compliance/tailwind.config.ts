import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}", "./lib/**/*.{ts,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: ["var(--font-noto-sans)", "system-ui", "sans-serif"],
        heading: ["var(--font-montserrat)", "var(--font-noto-sans)", "system-ui"]
      },
      colors: {
        csir: { navy: "#06224a", blue: "#0b63ce", green: "#10b981" }
      }
    }
  },
  plugins: []
};
export default config;
